﻿namespace Utilities
{
    public enum UserType
    {
        ADMIN,
        MEMBER
    }
}
